package br.com.gft.interfaces;

import br.com.gft.model.Livro;

public interface Imposto {

    public double calculaImposto();


}
